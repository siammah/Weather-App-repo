Simple weather app with UI and uses API key
